package com.sky.basket;

import java.math.BigDecimal;
import java.util.List;

public class BasketService {
    public BigDecimal calculate(List<String> subscriptions) throws BasketConditionNotMetException {
        return null;
    }
}
