package com.sky.subscription;

public class SubscriptionNotFoundException extends RuntimeException {
}
